import{r as e}from"./vendor.3c7e9b6e.js";export default function(){return e.createElement("div",null,"deep child")}
